using System;
using UnityEngine;

[System.Serializable]
public class GameData

{
    public int health;
    public int currency;
    public float[] playerPosition;

    public GameData(Vector3 position, int currentHealth, int currentCurrency)
    {
    
        playerPosition = new float[3];
        playerPosition[0] = position.x;
        playerPosition[1] = position.y;
        playerPosition[2] = position.z;
       
        health = currentHealth;
        currency = currentCurrency;

    }
}