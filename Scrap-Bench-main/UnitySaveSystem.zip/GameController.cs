using UnityEngine;

public class GameController : MonoBehaviour
{
    public Transform playerTransform;
    public int currentHealth = 100;
    public int currentCurrency = 10;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F5))
        {
            Save();
        }

        if (Input.GetKeyDown(KeyCode.F9))
        {
            Load();
        }
    }

    public void Save()
    {
        SaveSystem.SaveGame(playerTransform.position, currentHealth, currentCurrency);
    }

    public void Load()
    {
        GameData data = SaveSystem.LoadGame();

        if (data != null)
        {
            Vector3 targetPosition = new Vector3(
                data.playerPosition[0],
                data.playerPosition[1],
                data.playerPosition[2]
            );

            playerTransform.position = targetPosition;

            currentHealth = data.health;
            currentCurrency = data.currency;
        }
    }
}
