using System.IO;
using UnityEngine;

public static class SaveSystem
{
    private static string GetSavePath() => Application.persistentDataPath + "/savegame.json";

    public static void SaveGame(Vector3 position, int health, int currency)
    {
        GameData data = new GameData(position, health, currency);

        string json = JsonUtility.ToJson(data, true);

        File.WriteAllText(GetSavePath(), json);
        Debug.Log("Game Saved to: " + GetSavePath());
    }
    public static GameData LoadGame()
    {
        string path = GetSavePath();

        if (File.Exists(path))
        {
        string json = File.ReadAllText(path);

        GameData data = JsonUtility.FromJson<GameData>(json);
        Debug.Log("Game Loaded successfully");
        return data;
        }
        else
        {
        Debug.LogWarning("No save file found at " + path);
        return null;

        }
    }
}
